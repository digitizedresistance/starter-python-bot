# range - gives you the range of a given portal
# "/bot range resonators
# "/bot range resonators mods
# resonators must be from [12345678] (levels of the resonators)
# mods must be from [lLuUvV] (mods: LA / ULA / VRLA)
# example: /bot range 88776666 LL for 2R8 2R7 4R6 and 2 LA

import hangups
import plugins
import math

def _initialise(bot):
    plugins.register_user_command(["range"])

def range(bot, event, *args):
	examples = "<i>/bot range resonators<br>/bot range resonators mods<br>-> resonators from [12345678]<br>-> mods from [lLuUvV] (LA/ULA/VRLA)</i>"
	if len(args) == 0:
		bot.send_message_parsed(event.conv, "Error, you must supply some resonators<br>"+examples)
		return
	current_resonators = args[0]
	if len(current_resonators) < 8:
		bot.send_message_parsed(event.conv, "Error, not enough resonators to link this portal<br>"+examples)
		return
	elif len(current_resonators) > 8: 
		bot.send_message_parsed(event.conv, "Error, a portal can only own 8 resonators<br>"+examples)
		return
	level = 0
	for i in current_resonators:
		if i not in "12345678":
			bot.send_message_parsed(event.conv, "Error, resonators must be from [12345678]<br>"+examples)
			return
		try:
			level += int(i)
		except ValueError:
			bot.send_message_parsed(event.conv, "Error, resonators must be from [12345678]<br>"+examples)
	range = ((level/8)**4)*160/1000
	range = math.floor(range*100)/100
	if len(args) <= 1:
		bot.send_message_parsed(event.conv, "Range of the portal: <b>{}</b>km".format(range))
		return
	current_mods = args[1]
	mods = {
		"l": 2,
		"u": 5,
		"v": 7,
		1: 1,
		2: 0.25,
		3: 0.125,
		4: 0.125
	}
	if len(current_mods) > 4:
		bot.send_message_parsed(event.conv, "Error, a portal can only own 4 mods"+examples)
		return
	current_mods = "".join(sorted(current_mods.lower(), reverse=True))
	mult = 0
	pos = 1
	for i in current_mods:
		if i not in "lvu":
			bot.send_message_parsed(event.conv, "Error, mods must be from [lLuUvV]<br>"+examples)
			return	
		mult += mods[i] * mods[pos]
		pos += 1
	range = range * max(1, mult)
	range = math.floor(range*100)/100
	bot.send_message_parsed(event.conv, "Range of the portal: <b>{}</b>km".format(range))