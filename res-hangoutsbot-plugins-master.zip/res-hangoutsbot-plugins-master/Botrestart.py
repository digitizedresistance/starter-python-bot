from pushbullet import Pushbullet
import os

pb = Pushbullet('PUT YOUR PUSHBULLET API KEY HERE')
# Add cookies, log, config.json and memory.json if unique/multiple bots on same instance
cmd = 'python3 hangupsbot/hangupsbot.py'

for i in range(1, 8):
   os.system(cmd)

print("Max number of bot restarts reached")

pb.push_note('Hangouts Bot', 'Maximum number of bot restarts reached!!')
