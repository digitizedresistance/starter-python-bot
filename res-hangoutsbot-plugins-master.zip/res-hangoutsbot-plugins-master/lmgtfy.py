import hangups
from hangups.ui.utils import get_conv_name
import asyncio
import plugins

def _initialise(Handlers, bot=None):
    """
    first, you can setup stuff, initialise variables and whatever else!
    """
    plugins.register_user_command(["lmgtfy"]) 
    
    # above command is available to all users
    # Handlers.register_admin_command() if command(s) only available to admins
    return [] # always a blank list

@asyncio.coroutine
def lmgtfy(bot, event, *args):
    str = "http://lmgtfy.com/?q="+'+'.join(args)
    bot.send_message_parsed(event.conv, str)
