import logging
import hangups

from utils import unicode_to_ascii
import urllib.request

import plugins

logger = logging.getLogger(__name__)


def _initialise(bot):
    plugins.register_user_command(["score"])


def score(bot, event, *args):
    """find keywords in a specified spreadsheet"""

    # Check if watching for new adds is enabled
    if not bot.get_config_suboption(event.conv_id, 'reswar_score'):
        logger.info("Convid {} does not have reswar_score enabled.".format(event.conv_id))
        return
    if not bot.get_config_suboption(event.conv_id, 'reswar_spreadsheet'):
        bot.send_message_parsed(event.conv, _("reswar spreadsheet not set"))
        return
    reswar_spreadsheet = bot.get_config_suboption(event.conv_id, 'reswar_spreadsheet')

    # Adapted from http://stackoverflow.com/questions/23377533/python-beautifulsoup-parsing-table
    from bs4 import BeautifulSoup
    htmlmessage = "<strong>RESWAR SCORE</strong><br />"
    counter = 0
    import csv
    #with open('/home/frd/reswar/reswar_score.csv', 'r') as csvfile:
    with open(reswar_spreadsheet, 'r') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for row in spamreader:
            if counter <= 1:
                for datapoint in row:
                    htmlmessage += '{} '.format(datapoint)
                htmlmessage += '<br />'
            else:
                htmlmessage += _('{}: ').format(counter-1)
                for datapoint in row:
                     htmlmessage += '{} '.format(datapoint)
                htmlmessage += '<br />'
            counter += 1
    bot.send_html_to_conversation(event.conv, htmlmessage)
