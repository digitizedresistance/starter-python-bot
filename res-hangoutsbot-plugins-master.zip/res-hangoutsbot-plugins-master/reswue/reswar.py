import logging
import plugins
import requests

log = logging.getLogger(__name__)

def _initialise(bot):
    plugins.register_user_command(["reswar"])

def reswar(bot, event, *args):
  '''
  Displays the current ResWar leaderboard
  Kill marked portals in ResWue, then mark the alert resolved to earn the points
  '''
  try:
    # Check all required config options are set
    agent = bot.get_config_option('ResWue-Auth-AgentName')
    op = bot.get_config_option('ResWue-Auth-OperationName')
    pw = bot.get_config_option('ResWue-Auth-OperationPassword')
    html = ''
    if not agent:
      html += "Please set ResWue-Auth-AgentName (/bot config set ResWue-Auth-AgentName \"value\")<br>"
    if not op:
      html += "Please set ResWue-Auth-OperationName (/bot config set ResWue-Auth-OperationName \"value\")<br>"
    if not pw:
      html += "Please set ResWue-Auth-OperationPassword (/bot config set ResWue-Auth-OperationPassword \"value\")<br>"
    if html:
      yield from bot.coro_send_message(event.conv_id, html)
      return

    headers = {'Content-Type':'application/json', 'ResWue-Client': 'fi.resistance.scoreboard', 'ResWue-ApiKey': '55f1a5c2712e9', 'ResWue-ClientEnvironment': 'https://ops.irde.net/iitc/reswue', 'ResWue-Auth-AgentName': agent, 'ResWue-Auth-OperationName': op, 'ResWue-Auth-OperationPassword': pw, 'ResWue-Auth-Team': 'RESISTANCE'}
    alerts = requests.get('https://ops.irde.net/iitc/reswue/api/v1/{}/alerts/all'.format(op), headers=headers).json()
    if type(alerts) is dict and 'message' in alerts:
      yield from bot.coro_send_message(event.conv_id, 'ResWue server replied: "{}" - is your password correct?'.format(alerts['message']))
      return
    secret = 50
    try:
      info = requests.get('https://ops.irde.net/iitc/reswue/api/v1/{}/info'.format(op), headers=headers).json()
      secret = json.loads(info['settings']['reswue-games-secret'])['pointsPerTarget']
    except:
      pass
    scoreboard = {}
    for alert in alerts:
      agent = alert['resolver']['agentName']
      if agent:
        if alert['comment']:
          try:
            points = int(alert['comment'].split()[1])
          except:
            log.error('Unable to parse {}'.format(alert['comment']))
            continue
        else:
          points = secret # Secret target
        if agent in scoreboard:
          scoreboard[agent] += points
        else:
          scoreboard[agent] = points

    scoreboard = sorted(scoreboard.items(), key=lambda x: x[1], reverse=True)

    html = '<b>Current score:</b><br>'
    for i,(player,score) in enumerate(scoreboard):
      html += '<b>{}</b>: {} ({} points)<br>'.format(i + 1, player, score)
    yield from bot.coro_send_message(event.conv_id, html)
  except Exception as e:
    log.error(e)
    yield from bot.coro_send_message(event.conv_id, 'Unable to get ResWue alerts right now')
