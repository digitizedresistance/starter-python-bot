# 
# Steps to install/configure beyond the usual:
# - Pass credentials to this script either by setting environment variables or hardcoding into this script
#   - SYNCHANGOUTS_ign
#   - SYNCHANGOUTS_email
#   - SYNCHANGOUTS_password
# - For each op you want to sync:
#   - Ensure that the user specified above is a member of your op (if you're not using your own credentials)
#   - In the RESWUE backend, go to Tool / Config / Advanced Configuration.  Add a SyncHangouts entry and set to True or TeamsOnly.
#




import requests
import json
import hangups
import plugins
import sys,traceback
import asyncio
import logging
import time
import threadmanager
import configparser
import datetime
import os

# TODO
# - add error handling in case bot is registered at only one of NA or EU.
# - changing the team name on the RESWUE side results in a new hangout

# changelist
# - Added TeamsOnly option for RESWUE SyncHangouts value
# - Added check of environment variables for bot account parms

logger = logging.getLogger(__name__)


internal = {}


def _initialise(bot):

    #start "cron" tasks
    plugins.start_asyncio_task(reswue_sync)


@asyncio.coroutine
def reswue_sync(bot):
    """runs in a separate thread - to prevent the processor from being
    consumed entirely, we sleep for 5 seconds on each loop iteration"""

    last_run = [0, 0]

    rw = reswue(bot)

    while True:
        timestamp = time.time()

        yield from asyncio.sleep(5)
        # run sync jobs every 120.
        try:
            if timestamp - last_run[0] > 120:

                #na
                rw.environment="https://ops.smurfintelcorps.net"
                yield from rw.start()

                #eu
                #rw.environment="https://ops.irde.net"
                #yield from rw.start()

                last_run[0] = timestamp
        except:
            last_run[0] = timestamp
            print("-"*60)
            traceback.print_exc(file=sys.stdout)
            print("-"*60)


######################################################
# ResWue Class
#	sync(),authenticate(),get_ops(),get_agents()
######################################################

class reswue:
    bot = None
    busy = False
    busycount = 0
    token = None
    tokentime = abs(time.time())
    environment = "" # this is set during runtime no need to edit.

    # edit these
    datafile = "reswue.ini" 	# text file location for tracking hangouts

    # Need to set up the parms to connect to the BOT account.  If you don't set them in the source code, the environment will be checked.
    ign = ""             		# IGN of the reswue bot account
    email="" 	                # g+ email of reswue bot account
    password="" 	            # password of same accnt



    def __init__(self, bot):
        self.bot = bot

    @asyncio.coroutine
    def start(self):
        if self.busy:
            print("cron busy")
            self.busycount = self.busycount + 1
            if self.busycount < 10:
                return
            else:
                print("cron busycount exceeded... trying anyway.")

        self.busy = True
        self.busycount = 0
        yield from self.sync()

    @asyncio.coroutine
    def sync(self):

        session = requests.Session()
        requests.packages.urllib3.disable_warnings()
        print("############## RW Sync ### Sync Start.")    

        if self.ign is "":
            self.ign = os.environ['SYNCHANGOUTS_ign']

        if self.email is "":
            self.email = os.environ['SYNCHANGOUTS_email']

        if self.password is "":
            self.password = os.environ['SYNCHANGOUTS_password']

        if self.authenticate(session):
          try:
              operations=json.loads(self.get_ops(session))
              print("############## RW Sync ### member of {} ops".format(len(operations)))
              for op in operations:
                  if op["settings"].get("SyncHangouts"): 
                      print("############## RW Sync ### Operation {} enabled for HO Sync. Requesting agent list.".format(op["name"]))
                      ###
                      data=json.loads(self.get_agents(session,op["name"]))
                      agents=data.get("agents")
                      groups=data.get("groups")
                      if not agents:
                          print("############## RW Sync ### ERROR: No Agents: member of ({}) but access has been removed.".format(op["name"]))
                          continue
                      if not groups:
                          print("############## RW Sync ### ERROR: no groups returned")
                      
                      agent_data={}
                      agent_id_list=[]
          
                      print("############## RW Sync ### {} agents in operation.".format(len(agents)))          
                      for agent in agents:
                          agent_data[agent["agentName"]]={}
                          agent_data[agent["agentName"]]=agent
                          if agent.get("googleId"):agent_id_list.append(agent.get("googleId"))

                      sync_all_members = 1
                      
                      if op["settings"].get("SyncHangouts") == "TeamsOnly":
                          sync_all_members = 0

                      if sync_all_members:
                          # check if ho exists.
                          ho_name="{} - ALL MEMBERS".format(op["name"])
                          print("############## RW Sync ### checking existance of hangout: {}".format(ho_name))
                    
                          hangout = self.bot.conversations.get("text:{}".format(ho_name))
                          hangout = self.get_data(ho_name)
                                          
                          ho_conv = hangout
                                                                                             
                          if hangout:
                              print("############## RW Sync ###  Syncing ...")
                              #this will fail if there's nobody to add. so ... handle better later.
                              try:
                                  yield from self.bot._client.adduser(hangout, agent_id_list)
                              except: pass
                          else:
                              print("############## RW Sync ### NEW HO: creating: {} - members: {}".format(ho_name,agent_id_list))
                              #create rw hangout. add users. set name.
                              
                              response = yield from self.bot._client.createconversation(agent_id_list, force_group=True)
                              new_conversation_id = response['conversation']['id']['id']
                              self.set_data(ho_name,new_conversation_id)
                              yield from self.bot.coro_send_message(new_conversation_id, _("ResWue Operation: {} - Operation Hangout Created.".format(ho_name)))
                              yield from asyncio.sleep(1)
                              yield from self.bot._client.setchatname(new_conversation_id, ho_name)

                              #check teams
                              print("############## RW Sync ### {} groups in operation.".format(len(groups)))
                      for group in groups:
	 	          #skip default team
                          if group["groupName"] == "All":continue
                          # check if ho exists.
                          group_ho_name="{}: {} #TEAM#".format(group["groupName"],op["name"])
                          print("############## RW Sync ### checking existance of hangout: {}".format(group_ho_name))
                          #hangout = self.bot.conversations.get("text:{}".format(group_ho_name))
                          hangout = self.get_data(group_ho_name)
                          ho_conv = hangout
                          members=group.get("members")
                          if members:
                              team_members_id = []
                              for i in range(0,len(members)):
                                  if agent_data[members[i]]["googleId"]:team_members_id.append(agent_data[members[i]]["googleId"])
                          else: continue
                                                                                                                                               
                          if hangout:
                              print("############## RW Sync ### Syncing....")
                              #this will fail if there's nobody to add. so ... handle better later.
                              try:
                                  yield from self.bot._client.adduser(hangout, team_members_id)      
                              except: pass
                          
                          else:
                              response = yield from self.bot._client.createconversation(team_members_id, force_group=True)
                              new_conversation_id = response['conversation']['id']['id']
                              self.set_data(group_ho_name,new_conversation_id)
                              yield from self.bot.coro_send_message(new_conversation_id, _("ResWue Operation: {} - Operation Team Hangout Created.".format(group_ho_name)))
                              yield from asyncio.sleep(1)
                              yield from self.bot._client.setchatname(new_conversation_id, group_ho_name)
                      
                    
              print("############## RW Sync ### Sync Complete")
              self.busy = False
              return
                    
          except:
              print("-"*60)
              traceback.print_exc(file=sys.stdout)
              print("-"*60)
              self.busy = False
              return

    def get_agents(self,session,operation):
            client = "net.irde.ops.reswue.plugin:2"
            url = '{}/iitc/reswue/api/v1/{}/agents/all'.format(self.environment,operation)
            rwheaders = {'Content-type': 'application/json', 'Accept': 'text/plain', 'ResWue-Client': client,'ResWue-ApiKey': '54998c15d4335', 'ResWue-Auth-OperationName':operation,'ResWue-Auth-AgentName':self.ign,'ResWue-Auth-Team':'RESISTANCE'}
            agents = session.get(url, headers=rwheaders)
            try:
                return agents.text
            except:
                print("error returning operation agents")
            return False

    def get_ops(self,session):
            client="net.irde.ops.agentclient:37"
            client = "net.irde.ops.reswue.plugin:2"
            rwheaders = {'Content-type': 'application/json', 'Accept': 'text/plain', 'ResWue-Client': client,'ResWue-ApiKey': '54998c15d4335', 'ResWue-Auth-OperationName':'-none-','ResWue-Auth-AgentName':self.ign,'ResWue-Auth-Team':'RESISTANCE'}
            url = '{}/iitc/reswue/api/v1/operations/my/{}'.format(self.environment,self.ign)
            ops = session.get(url, headers=rwheaders)
            try:
                return ops.text
            except:
                print("error returning ops")
                return False

    def authenticate(self,session):
            if not self.token or abs(time.time()-self.tokentime)>3000: # token expires in 1 hour
                print("############## RW Sync ### UPDATING AUTH TOKEN")
                EMAIL=self.email
                PASSWORD=self.password
                print("############## RW Sync ### Initiating Google OAuth2")
                authdata = dict(Email=EMAIL, Passwd=PASSWORD, service="oauth2:https://www.googleapis.com/auth/plus.me",client_sig="0924c5caa11b8482f0ebef3c357987f91df876b1", app="net.irde.ops.agentclient", has_permission=1)
                authreq = session.post('https://android.clients.google.com/auth', data=authdata, verify=False)
                if not 'Auth=' in authreq.text :
                    print(authreq.text)
                    print('############## RW Sync ### ERROR: No auth token obtained')
                    return False
                
                tmp = authreq.text.split("Auth=")
                authcode = tmp[1].split("\n")
                self.token=authcode[0]
                url="https://www.googleapis.com/oauth2/v1/userinfo?alt=json&access_token={}".format(self.token)
                r=session.get(url)
                google_info=json.loads(r.text)
                if google_info.get("id"):
                    print("############## RW Sync ### Successfully logged in as: {}".format(google_info['name']))
                else:
                    print("############## RW Sync ### ERROR: auth failure.")
                    print(r.text)
                    return False
                
                self.tokentime=time.time()
                                    
            ###### reswue######
            rwheaders = {
                "Accept-Encoding":"gzip, deflate",
                "User-Agent":"RESWUE Client for Android 7.2.0 (net.irde.ops.agentclient:37)",
                "ResWue-Client":"net.irde.ops.agentclient:37",
                "ResWue-ApiKey":"54998b92eed60",
                "ResWue-ClientEnvironment":"{}/iitc/reswue".format(self.environment),
                "ResWue-Auth-OperationName":"---rsl---",
                "ResWue-Auth-OperationPassword":"null",
                "ResWue-Auth-AgentName":self.ign,
                "ResWue-Auth-Team":"RESISTANCE",
                "Content-Type":"application/json"
                }
            tmp=self.token
            payload=json.dumps({"tokenType":"access_token", "token":tmp,"forgeryToken":"NOSTATE"})
            url = "{}/iitc/reswue/api/v1/agents/{}/sessions/google/token".format(self.environment,self.ign)
            r = session.post(url, data=payload, headers=rwheaders)
            rw_session = r.cookies.get_dict()
            if rw_session.get('ResWueLoggedIn'):
                print("############## RW Sync ### ResWue auth successfull. ResWueLoggedIn={}".format(rw_session['ResWueLoggedIn']))
                return True
            else:
                print("############## RW Sync ### ERROR: ResWue session cookie not set. fail.")
                print(r.text)
                return False
            
    def set_data(self,ho_name,conv_id):
            try:
                config = configparser.ConfigParser()
                config.read(self.datafile)
                config.add_section(ho_name)
                config.set(ho_name,'conv_id',conv_id)
                config.set(ho_name,'timestamp',datetime.datetime.now().strftime("%m-%d-%Y (%R)"))
                with open(self.datafile, 'w') as configfile:
                    config.write(configfile)
            except configparser.DuplicateSectionError as e:
                return "duplicate"
            except:
                print("config error")
                print("-"*60)
                traceback.print_exc(file=sys.stdout)
                print("-"*60)
                return False
                
    def get_data(self,ho_name):
            config = configparser.ConfigParser()
            config.read(self.datafile)
            try:
                conv_id = config.get(ho_name,'conv_id')
                return conv_id
            except configparser.NoSectionError as e:
                return False    
            except:
                print("-"*60)
                traceback.print_exc(file=sys.stdout)
                print("-"*60)
                return False

