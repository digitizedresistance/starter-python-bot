# Reswue hangoutbot plugins
Private repository curating plugins available for resistance only

### Plugins
- [**Reswar**] (reswar.py) : Alternative reswar plugin. Outputs reswar score to hangout. Set the config options ResWue-Auth-AgentName, ResWue-Auth-OperationName, ResWue-Auth-OperationPassword.
- [**Reswue to hangouts**] (reswue_to_hangouts.py) : Sync RESWUE op membership to hangouts.  Creates hangouts and adds new trusted agents to teams and an op HO.  Does not do anything with legacy agents.
- [**Reswar Score**] (score.py) : Outputs reswar score to hangout. add "reswar_score": true,"reswar_spreadsheet":"csv_location" under wanted conversation_ID, and needs reswue_scoreboard_backend.pl to make scoreboard csv file ! score


### Scripts
-  [**reswue scoreboard backend**](reswue_scoreboard_backend.pl) : _missing_


### Config.json
_Missing explanation about the config.json here._