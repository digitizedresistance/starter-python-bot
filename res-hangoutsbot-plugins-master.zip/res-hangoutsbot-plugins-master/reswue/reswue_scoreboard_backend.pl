#!/bin/perl -w
use strict;
use warnings;
use LWP::Simple;
use JSON;
use JSON::Parse 'valid_json';
use Text::xSV;
use Data::Dumper;
use Time::Piece;
use WWW::Mechanize;
use HTTP::Cookies;
use Carp;
use Getopt::Long;
use Pod::Usage;
use File::Basename;
use HTTP::Cookies;
use Switch;
use POSIX qw(strftime :sys_wait_h);
use File::Copy;
############################################################################################
my $reswue_operation_name;
my $operation_password;
my $operation_general;
my $homefolder;
my $csvscorefile;
#############################################################################################
my $config_filename = "config.json"; #PATH to config.json
my $baseurl = "https://ops.irde.net/iitc/reswue/api/v1/";
my $opt_clean_scoreboard = 0;
my $opt_print_scoreboard = 0;
my $opt_no_alerts = 1;
my $opt_silent;
my $opt_debug;
my $csvlogfile = sprintf("%s-reswar_scorelogfile.csv", csvdatestamp());
my $alertdatafile = sprintf("%s-alertsdata_out.json", csvdatestamp());
GetOptions(
	"noalerts=i"               => \$opt_no_alerts,
	"scoreboardclean=i"               => \$opt_clean_scoreboard,
	"scoreboardprint=i"               => \$opt_print_scoreboard,
	"silent"               => \$opt_silent,
	"debug"               => \$opt_debug,
) or pod2usage(-verbose => 1) && exit;
###################################################################################################
# -- Main process --------------------------------------------------------
	&print_process_line("Getting Reswue Config ...\n") unless $opt_silent;
	my $config = &read_config_json();
	if ($config) { exit };
	&print_process_line("Getting Reswue Config  OK\n") unless $opt_silent;
	&print_process_line("Getting Reswue Config ...\n") unless $opt_silent;
	my $json = JSON->new->allow_nonref;
	my $reswue_operation_conf = $json->decode(&post_reswue(&get_make_reswue_requests('/info')));
	$reswue_operation_conf = $reswue_operation_conf->{settings};
	&reswue_operation_conf_check() if $opt_debug;
	&print_process_line("Getting Reswue Config DONE\n") unless $opt_silent;
	&print_process_line("Getting Reswue Alerts ...\n") unless $opt_silent;
	my $all_alerts_reswue = post_reswue(get_make_reswue_requests('/alerts/all'));
	&print_process_line("Getting Reswue Alerts DONE\n") unless $opt_silent;
	if ( $opt_no_alerts ) { 
		&print_process_line("Writing Reswue alerts to disk\n") unless $opt_silent;
		&write_to_disk($all_alerts_reswue);
		&print_process_line("Writing Reswue alerts to disk DONE\n") unless $opt_silent;
	}
	&print_process_line("Generating Scoreboard ...\n") unless $opt_silent;
	make_scoreboard($all_alerts_reswue);
	&print_process_line("Generating Scoreboard : DONE\n") unless $opt_silent;
	copy_to_latest();
	if ( $opt_clean_scoreboard ) {
		&print_process_line("Cleaning Reswue alerts ...\n") unless $opt_silent;
		&go_through_alerts_reswue($all_alerts_reswue);
		&print_process_line("Cleaning Reswue alerts : DONE\n") unless $opt_silent;
	}
###################################################################################################
#
# Sub funtions start her
#
sub read_config_json {
	my $error = 0;
	my $json_text = do {
	   open(my $json_fh, "<:encoding(UTF-8)", $config_filename)
	      or die("Can't open \$config_filename\": $!\n");
	   local $/;
	   <$json_fh>
	};
	
	my $json = JSON->new;
	my $data = $json->decode($json_text);
         if ( not defined $data->{'operation_general'} ) {
		print "Operation_general nott filled on $config_filename\n";
		$error=1;
	}else {
		$operation_general = $data->{'operation_general'};
	}
         if ( not defined $data->{'csvscorefile'}) {
		print "Operation_general not filled on $config_filename\n";
		$error=1;
	}else {
		$csvscorefile = $data->{'csvscorefile'};
	}
         if ( not defined $data->{'homefolder'}) {
		print "Operation_general not filled on $config_filename\n";
		$error=1;
	}else {
		$homefolder = $data->{'homefolder'};
	}
         if ( not defined $data->{'operation_password'}) {
		print "Operation_general not filled on $config_filename\n";
		$error=1;
	}else {
		$operation_password = $data->{'operation_password'};
	}
         if ( not defined $data->{'reswue_operation_name'}) {
		print "Operation_general not filled on $config_filename\n";
		$error=1;
	}else {
		$reswue_operation_name = $data->{'reswue_operation_name'};
	}
 if ( $error ) {
	print "Exit because configuration missing on $config_filename\n";
		return 1;
	} else {
		return 0;
	}
}
sub write_to_disk {
	my $data = shift;
	$data = decode_json($data);
	open my $fh, ">", $homefolder."/".$alertdatafile;
	print $fh encode_json($data);
	close $fh;
}
sub copy_to_latest {
	copy($homefolder."".$csvlogfile,$homefolder."".$csvscorefile) or die "Copy failed: $!";
}
sub reswue_operation_conf_check {
		&print_process_line("Cheacking Active games ...\n") unless $opt_silent;
if ( not defined $reswue_operation_conf->{'reswue-games-p8hunt'} ) {
		&print_process_line("                          : P8 hunt not active on settings\n") unless $opt_silent;
}
 if (not defined $reswue_operation_conf->{'reswue-games-hphunt'} ) {
		&print_process_line("                          : HP hunt not active on settings\n") unless $opt_silent;
}
 if (not defined $reswue_operation_conf->{'reswue-games-anchorhunt'} ) {
		&print_process_line("                          : Anchor Hunter active on settings\n") unless $opt_silent;
}
 if (not defined $reswue_operation_conf->{'reswue-games-random'} ) {
		&print_process_line("                          : Random hunt active on settings\n") unless $opt_silent;
}
 if (not defined $reswue_operation_conf->{'reswue-games-secret'} ) {
		&print_process_line("                          : Secret hunt active on settings\n") unless $opt_silent;
}
if ( not defined $reswue_operation_conf->{'reswue-games-homeupgrade'} ) {
		&print_process_line("                          : Home Upgrade active on settings\n") unless $opt_silent;
}
		&print_process_line(" If settings are missing scores of game is skipped..\n") unless $opt_silent;

} 
sub go_through_alerts_reswue {
 	my $alerts = shift;
	my @score_alerts;
	my $json_a = decode_json($alerts);
	foreach my $data( @$json_a ) {
		if ( $data->{resolvedDate} && $data->{resolvedDate} ne 'undef' ) {
			my $response = &delete_reswue_alert($data->{id});
			if ( $response =~ /OK/ ) {
				print STDERR ".";
			} else {
				print STDERR $response;
			}
		}	
	}
}
sub delete_reswue_alert { 
	my $alertId = shift;
	my $req = &post_make_reswue_requests('/alerts/'.$alertId.'/delete');
	my $time = localtime;
	my $currentDate =  $time->datetime;	
	my $json = JSON->new->allow_nonref;
	my $data = {id => $alertId,'deleter' => { "agentName" => $operation_general},'deleteDate' => $currentDate};
	my $content = $json->encode($data);
	$req->content($content);
	my $response = &post_reswue($req);
        return $response;
}
sub post_make_reswue_requests {
	my $operation = shift;
	my $url = $baseurl.$reswue_operation_name.$operation;
	#print "URL:" . $url."\n";
	my $req = HTTP::Request->new(POST => $url);
	$req->header('Authorization' => 'Bearer 4/ux3B30odSC0QLUYx5Ciqr_e155_GCOWFJLTtp8aXRdk');
	$req->header('content-type' => 'application/json');
	$req->header('ResWue-Client' => 'fi.resistance.scoreboard');
	$req->header('ResWue-ApiKey' => '55f1a5c2712e9');
	$req->header('ResWue-ClientEnvironment' => 'https://ops.irde.net/iitc/reswue');
	$req->header('ResWue-Auth-AgentName' => ''.$operation_general.'');
	$req->header('ResWue-Auth-OperationName' => ''.$reswue_operation_name.'');
	$req->header('ResWue-Auth-OperationPassword' => ''.$operation_password.'');
	$req->header('ResWue-Auth-Team' => 'RESISTANCE');
	return $req;
}

sub get_make_reswue_requests {
	my $operation = shift;
	my $url = $baseurl.$reswue_operation_name.$operation;
	#print "URL:" . $url."\n";
	my $req = HTTP::Request->new(GET => $url);
	$req->header('content-type' => 'application/json');
	$req->header('ResWue-Client' => 'fi.resistance.scoreboard');
	$req->header('ResWue-ApiKey' => '55f1a5c2712e9');
	$req->header('ResWue-ClientEnvironment' => 'https://ops.irde.net/iitc/reswue');
	$req->header('ResWue-Auth-AgentName' => ''.$operation_general.'');
	$req->header('ResWue-Auth-OperationName' => ''.$reswue_operation_name.'');
	$req->header('ResWue-Auth-OperationPassword' => ''.$operation_password.'');
	$req->header('ResWue-Auth-Team' => 'RESISTANCE');
	return $req;
}
sub post_reswue {
	my $req = shift;
	my $ua = LWP::UserAgent->new;
	my $resp = $ua->request($req);
	if ($resp->is_success) {
		if ( defined $resp->decoded_content && $resp->decoded_content ne "") {
			my $message = $resp->decoded_content;
		} else {
			my $message = $resp->message;
		}
	}
	else {
	    print "HTTP GET error code: ", $resp->code, "\n";
	    print "HTTP GET error message: ", $resp->message, "\n";
	}
}

sub make_scoreboard {
	my $alerts_data = shift;
	my $json_a = decode_json($alerts_data);
	my %scoreboard;
	foreach my $data( @$json_a ) {
		if ( $data->{type} ne 'undef' && $data->{resolvedDate} && $data->{resolvedDate} ne 'undef' && $data->{type} =~ /DestroyPortalAlert|UpgradePortalAlert/m ) {
			my $points = 0;
			my $agent_name = $data->{resolver}->{agentName};
			switch ($data->{appData}) {
				case "reswue-games-tacticalhunt" {
								my $json = JSON->new->allow_nonref;
								$data->{comment} =~ m/RESWAR:.([0-9]{1,}).Points/i;
								$points = $1;
								#print "tacticalhun :". $points."\n";
								}
				case "reswue-games-p8hunt" { 	
								if ( defined $reswue_operation_conf->{'reswue-games-p8hunt'} ) { 
									my $json = JSON->new->allow_nonref;
									my $points_data = $json->decode($reswue_operation_conf->{'reswue-games-p8hunt'});
									$points = $points_data->{"pointsPerTarget"};
								}
								}
				case "reswue-games-p7hunt" { 	
								if ( defined $reswue_operation_conf->{'reswue-games-p7hunt'} ) { 
									my $json = JSON->new->allow_nonref;
									my $points_data = $json->decode($reswue_operation_conf->{'reswue-games-p7hunt'});
									$points = $points_data->{"pointsPerTarget"};
								}
								}
				case "reswue-games-hphunt" { 	
								if ( defined $reswue_operation_conf->{'reswue-games-hphunt'} ) { 
									my $json = JSON->new->allow_nonref;
									my $points_data = $json->decode($reswue_operation_conf->{'reswue-games-hphunt'});
									$points = $points_data->{"pointsPerTarget"};
								}
								}
				case "reswue-games-random" { 	
								if ( defined $reswue_operation_conf->{'reswue-games-random'} ) { 
									my $json = JSON->new->allow_nonref;
									my $points_data = $json->decode($reswue_operation_conf->{'reswue-games-random'});
									$points = $points_data->{"pointsPerTarget"};
								}
								}
				case "reswue-games-secret" { 	
								my $json = JSON->new->allow_nonref;
								if ( defined $reswue_operation_conf->{'reswue-games-secret'} ) { 
									my $points_data = $json->decode($reswue_operation_conf->{'reswue-games-secret'});
									$points = $points_data->{"pointsPerTarget"};
								}
								}
				case "reswue-games-homeupgrade" {
								if ( defined $reswue_operation_conf->{'reswue-games-homeupgrade'} ) { 
									my $json = JSON->new->allow_nonref;
									my $points_data = $json->decode($reswue_operation_conf->{'reswue-games-homeupgrade'});
									$points = $points_data->{"pointsPerTarget"};
								}
				}
				case qr/reswue-games-anchorhunt:.*/ { 
								if ( defined $reswue_operation_conf->{'reswue-games-anchorhunt'} ) {
									my ($t,$p) = split(/:/,$data->{appData}); 
									$points = $p;
								}
				}
				case qr/reswue-games-sideload:.*/ { 
								if ( defined $reswue_operation_conf->{'reswue-games-anchorhunt'} ) {
									my ($t,$p) = split(/:/,$data->{appData}); 
									$points = $p;
								}
				}
			}
			if ( defined $scoreboard{$agent_name} ) {
			 	if ( $data->{comment}  =~ m/Virus Required/ig ) { 
					$points = $points * 5;
				}
				$scoreboard{$agent_name} =  $scoreboard{$agent_name} + $points;
			} else {
			 	if ( $data->{comment}  =~ m/Virus Required/ig ) { 
					$points = $points * 5;
				}
			 	$scoreboard{$agent_name} =  $points;
			}
		}
	}
	my $csv = Text::xSV->new(sep => ';',filename => $homefolder."".$csvlogfile);
	if ( $opt_print_scoreboard ) {
		print "\n========================RESWAR SCOREBOARD===================\n";
	        printf "%s;%s\n","DATE",datestamp();
	        printf "%s;%s\n","AGENTNAME","POINTS";
	}
		$csv->print_row("DATE",datestamp());
		$csv->print_row("AGENTNAME","POINTS");
	foreach my $key (sort { $scoreboard{$b} <=> $scoreboard{$a} } keys %scoreboard) {
		if ( $opt_print_scoreboard ) {
	        	printf "%s;%d\n", $key, $scoreboard{$key};
		}
		$csv->print_row($key,$scoreboard{$key});
	    }
	if ( $opt_print_scoreboard ) {
		print "============================================================\n";
	}
}
sub print_process_line {
	my $data = shift;
	printf STDERR ('%s %s',timestamp(),$data);
}
sub csvdatestamp { return strftime("%d.%m.%Y-%H%M%S", localtime); }
sub datestamp { return strftime("%d.%m.%Y %H:%M", localtime); }
sub timestamp { return strftime("%Y-%m-%d %H:%M:%S", localtime); }

