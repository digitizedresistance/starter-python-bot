import plugins

def _initialise(bot):
    plugins.register_user_command(["count"])
    
def count(bot, event, *args):
    loop = 0
    while (loop <= 10000):
        yield from bot.coro_send_message(event.conv, _("{}").format(loop))
        loop = loop + 1
