not knowing linux well enough, i think i butchered this a bit but it works
may be specific to amazon ec2 ubuntu 14.04, maybe not

create file bot.sh in ~/hangoutsbot
```
#!/bin/bash
screen -U -dmS hangoutsbot bash -c "source ~/.venv/hangoutsbot/bin/activate; python3 ~/hangoutsbot/hangupsbot/hangupsbot.py"
```
this assumes you have a virtual environment for the bot, if not you can remove that part of the command.

make it executable
`chmod 700 bot.sh`


then create file botboot.sh in ~/hangoutsbot
```
#!/bin/bash
su - ubuntu -c "nohup ~/hangoutsbot/bot.sh > ~/hangoutsbot/hangoutsbot.log 2>&1&"
```

make it executable and change permissions
```
chmod +x botboot.sh
sudo chown root botboot.sh
sudo chmod 744 botboot.sh
```

then create link in statup folder
`sudo ln -s /home/ubuntu/hangoutsbot/botboot.sh /etc/rc2.d/S99hangoutsbot`

reboot and check for screen `screen -ls`
