import asyncio
import plugins
import string
import json
import hangups
from commands import command
import random
import logging

STORAGE = "connect_storage"
logger = logging.getLogger(__name__)

def _initialise(bot):
    plugins.register_user_command(["link", "addmeto", "unlink"])

def link(bot, event, *args):
    """link current hangout with another hangout group to easily join
    Usage: /bot link with <hangout_id> <name>
    /bot link remove <hangout_id OR name> (or use /bot unlink)
    /bot link join <hangout_id OR name> (or use /bot addmeto)"""

    if not bot.memory.exists([STORAGE]):
        bot.memory.set_by_path([STORAGE], {})

    if not bot.memory.exists([STORAGE, event.conv_id]):
        bot.memory.set_by_path([STORAGE, event.conv_id], {})

    from_id = event.conv_id
    curr_user_id = event.user.id_.chat_id

    parameters = list(args)
    if parameters[0] == "with":
        # check if user is botkeeper
        #   sorry can't do that
        if len(parameters) == 1:
            yield from bot.coro_send_message(event.conv_id, 'No destination')
            return
        elif len(parameters) == 2:
            yield from bot.coro_send_message(event.conv_id, 'No name specified')
            return

        to_id = parameters[1]
        name = parameters[2]

        curr_conn = _get_link_by_id(bot, from_id, to_id)
        if not curr_conn is None:
            yield from bot.coro_send_message(event.conv_id, 'Connection already exists')
            return

        yield from _create_link(bot, from_id, to_id, curr_user_id, name) 
        connection = bot.memory.get_by_path([STORAGE, from_id])
        body = connection[to_id]
        name = body['name']
        yield from bot.coro_send_message(event.conv_id, 'Done connecting this hangout... {}'.format(name))
    
    elif parameters[0] == "remove":
        if len(parameters) < 2:
            yield from bot.coro_send_message(event.conv_id, 'Name or Id is missing')
            return;

        key = parameters[1]
        link = yield from _get_link(bot, event, from_id, key);
        if not link is None:
            for key in link:
                _remove_link(bot, from_id, key)
                yield from bot.coro_send_message(event.conv_id, 'Removed connection with {}'.format(link[key]['name']))

    elif parameters[0] == "join":
        if len(parameters) < 2:
            yield from bot.coro_send_message(event.conv_id, 'Name or Id is missing')
            return;

        key = parameters[1]
        yield from _add_me_to(bot, event, from_id, key, curr_user_id)

def unlink(bot, event, *args):
    """Remove link between hangouts
    Usage: /bot unlink <hangout_id OR name>"""

    if not bot.memory.exists([STORAGE]):
        bot.memory.set_by_path([STORAGE], {})

    if not bot.memory.exists([STORAGE, event.conv_id]):
        bot.memory.set_by_path([STORAGE, event.conv_id], {})

    from_id = event.conv_id
    curr_user_id = event.user.id_.chat_id
    parameters = list(args)

    if len(parameters) < 1:
        yield from bot.coro_send_message(event.conv_id, 'Name or Id is missing')
        return;

    key = parameters[0]
    link = yield from _get_link(bot, event, from_id, key);
    if not link is None:
        for key in link:
            _remove_link(bot, from_id, key)
            yield from bot.coro_send_message(event.conv_id, 'Removed connection with {}'.format(link[key]['name']))

def addmeto(bot, event, *args): 
    """Add yourself via a link to another hangout
    Usage: /bot addmeto <hangout_id OR name>"""

    if not bot.memory.exists([STORAGE]):
        bot.memory.set_by_path([STORAGE], {})

    if not bot.memory.exists([STORAGE, event.conv_id]):
        bot.memory.set_by_path([STORAGE, event.conv_id], {})

    from_id = event.conv_id
    curr_user_id = event.user.id_.chat_id
    parameters = list(args)

    if len(parameters) < 1:
        yield from bot.coro_send_message(event.conv_id, 'Name or Id is missing')
        return;

    key = parameters[0]
    yield from _add_me_to(bot, event, from_id, key, curr_user_id)    

@asyncio.coroutine
def _add_me_to(bot, event, from_id, query, user_id):
    link = yield from _get_link(bot, event, from_id, query)
    if not link is None:
        for key in link:
            list_add = []
            list_add.append(user_id)
            list_add = list(set(list_add))
            try:
                yield from bot._client.adduser(key, list_add)
            except hangups.exceptions.NetworkError as e:
                # trying to add a user to a group where the user is already a member raises this
                yield from bot.coro_send_message(event.conv_id, 'Oops, something went wrong. You might be already in this hangout.'.format(key, user_id))
                logger.exception("JOIN HANGOUT: FAILED {} {}".format(key, user_id))
                return
            # yield from bot.coro_send_message(key, 'Removed connection with {}'.format(link[key]['name']))

@asyncio.coroutine
def _get_link(bot, event, from_id, query):
    links = _get_link_by_id(bot, from_id, query)
    # If nothing found by id, look for the name
    if links is None:
        links = _get_link_by_name(bot, from_id, query)
    
    if links is None or len(links) is 0:
        yield from bot.coro_send_message(event.conv_id, 'Nothing found')
        return None;
    elif len(links) == 1:
        return links;
    elif len(links) > 1:
        html = _list_links_to_text(links)
        html.insert(0, "More hangouts found with this name, try using the hangout id:<br/>")
        output = "".join(html)
        yield from bot.coro_send_message(event.conv_id, output)
        return None;

def _get_link_by_id(bot, from_id, to_id):
    mem = bot.memory.get_by_path([STORAGE, from_id])
    if to_id in mem:
        links = {}
        links[to_id] = mem[to_id]
        return links
    else:
        return None

def _get_link_by_name(bot, from_id, name):
    connections = bot.memory.get_by_path([STORAGE, from_id])
    findings = {}

    for key in connections:
        conn = connections[key]
        # Maybe to a %like%
        if conn['name'] == name:
            findings[key] = conn
    return findings;
        
def _remove_link(bot, from_id, key_link):
    connections = bot.memory.get_by_path([STORAGE, from_id])
    connections.pop(key_link)
    bot.memory.set_by_path([STORAGE, from_id], connections)

def _list_links_to_text(links):
    text = []
    for num, key in enumerate(links):
        row = "<b>1. {}</b> ID: <i>{}</i><br/>".format(links[key]['name'], key)
        text.append(row)
    return text

@asyncio.coroutine
def _create_link(bot, from_id, to_id, by, name):
    body = {}
    body['key'] = to_id
    body['name'] = name
    body['by'] = by

    # Retrieve connection. If it doesnt exist yet, create an empty one
    connection = bot.memory.get_by_path([STORAGE, from_id])
    if connection is None:
        connection = {}

    connection[to_id] = body
    bot.memory.set_by_path([STORAGE, from_id], connection)
    return;

# def _remove_link(bot, from_id, to_id, by, name):
#     connection = bot.memory.get_by_path([STORAGE, from_id])
#     if connection is None:


