import hangups
from hangups.ui.utils import get_conv_name
import asyncio
import plugins

def _initialise(Handlers, bot=None):
    """
    first, you can setup stuff, initialise variables and whatever else!
    """
    plugins.register_admin_command(["os_uptime"]) 
    
    # above command is available to all users
    # Handlers.register_admin_command() if command(s) only available to admins
    return [] # always a blank list

def uptime():
 
     try:
         f = open( "/proc/uptime" )
         contents = f.read().split()
         f.close()
     except:
        return "Something went horribly wrong! Unload this plugin!"
 
     total_seconds = float(contents[0])
 
     # Helper vars:
     MINUTE  = 60
     HOUR    = MINUTE * 60
     DAY     = HOUR * 24
 
     # Get the days, hours, etc:
     days    = int( total_seconds / DAY )
     hours   = int( ( total_seconds % DAY ) / HOUR )
     minutes = int( ( total_seconds % HOUR ) / MINUTE )
     seconds = int( total_seconds % MINUTE )
 
     # Build up the pretty string (like this: "N days, N hours, N minutes, N seconds")
     string = ""
     if days > 0:
         string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
     if len(string) > 0 or hours > 0:
         string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
     if len(string) > 0 or minutes > 0:
         string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
     string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
 
     return string;


@asyncio.coroutine
def os_uptime(bot, event, *args):
    bot.send_message_parsed(event.conv, 'Server has been up for :' + uptime())
