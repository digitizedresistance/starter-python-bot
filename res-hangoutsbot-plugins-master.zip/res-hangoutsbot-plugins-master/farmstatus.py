# Status/Farm updates
# status - updates the user on the status of a cluster of portals
# updates are set manually by users
# everyone shares the same data so any updates in private messages are available to all
# "/bot status (cluster_name)" will provide the most recent info and timestamp
# "/bot status set (cluster_name) (new status)" will change the stored info
# commonly used areas have hard-coded url links (please change or remove)

import time
import plugins

def _initialise(bot):
    plugins.register_user_command(["status"])
    return []

def status(bot, event, *args):

	parameters = list(args)
	cluster = "oops"
	setStatus = "none"

	#set up the cluster of interest based on a "set" request
	if (parameters):
		if (parameters[0] == "set") :	
			setStatus = "set"
			cluster = parameters[1]
		else:
			cluster = parameters[0]
	cluster.lower()

	#change any short hand to long hand for common areas
	if (cluster=="dp"):
		cluster="duckpond"
		print ("changed to duckpond")
	elif (cluster=="gg"):
		 cluster="garrison"
	elif (cluster=="smu"):
		cluster="stmarys"

	#arrays for keeping track of the things
	cluster_status = []
	result = []
	
	#creating the gd memory
	if not bot.memory.exists(['status']):
		bot.memory.set_by_path(['status'], {})

	#if "set" is called, pop off the word set and the cluster name
	#then overwrite existing saved data
	if (setStatus == "set"):
		parameters.pop(0)
		parameters.pop(0)
		new_status = ' '.join(parameters)
		if (new_status):
			if bot.memory.exists(['status', cluster]):
				cluster_status = bot.memory.get_by_path(['status', cluster])
				for num, timestamp in enumerate(cluster_status):
					result.append(_("Previously {}").format(cluster_status[timestamp]))

			else:
				result.append(_("Setting brand new status"))

			bot.memory.set_by_path(['status', cluster], {})
			cluster_status = bot.memory.get_by_path(['status', cluster])

			cluster_status[str(time.time())] = new_status
			bot.memory.set_by_path(['status', cluster], cluster_status)
			result.append(_("Adding {}").format(new_status))
		else:
			result.append(_("Make sure you have a status update"))
	else:
		if not bot.memory.exists(['status', cluster]):
			if not cluster == "all":
				result.append(_("No farm found try: "))		
			all_clusters = bot.memory.get_by_path(['status'])
			for num, thing in enumerate(all_clusters):
				for area, timestamp in enumerate(all_clusters[thing]):
					if cluster == "all":
						cluster_status = bot.memory.get_by_path(['status', thing])
						result.append(_("<b>{}:</b> {} <b>- {} ago</b>").format(thing.title(),
																	cluster_status[timestamp],
																	_time_ago(float(timestamp)) ))
					else:
						result.append(_("{} - {} ago").format(thing.title(),_time_ago(float(timestamp)) ))
		else:
			cluster_status = bot.memory.get_by_path(['status', cluster])
			print (cluster_status)
			for num, timestamp in enumerate(sorted(cluster_status, key=float)):
				result.append(_("<b>{}:</b> {} <b>- {} ago</b>").format(cluster.title(),
																			cluster_status[timestamp],
																			_time_ago(float(timestamp)) ))

    #add custom urls to fav farms
	if (cluster=="duckpond"):
		result.append(_("https://goo.gl/1sxb1j"))
	elif (cluster=="garrison"):
		result.append(_("https://goo.gl/7JZZfL"))
	elif (cluster=="stmarys"):
		result.append(_("https://goo.gl/O88en7"))


	message = _("<br />".join(result))
	
	yield from bot.coro_send_message( event.conv_id, message)

	bot.memory.save()


def _time_ago(timestamp):
    time_difference = time.time() - timestamp
    if time_difference < 60: # seconds
        return _("{}s").format(int(time_difference))
    elif time_difference < 60*60: # minutes
        return _("{}m").format(int(time_difference/60))
    elif time_difference < 60*60*24: # hours
        return _("{}h").format(int(time_difference/(60*60)))
    else:
        return _("{}d").format(int(time_difference/(60*60*24)))
