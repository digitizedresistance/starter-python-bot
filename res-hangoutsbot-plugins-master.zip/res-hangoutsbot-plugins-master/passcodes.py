import asyncio
import plugins

#########################
# Passcode plugin, for forwarding passcodes from one room to another.
# Similar to the forwarding plugin, but removes the name bit so that
# the passcodes are copy-pasteable
#########################
# Usage:
# See https://github.com/hangoutsbot/hangoutsbot/wiki/Forwarding-Plugin
# But use 'passcode_enabled' and 'passcode_to' instead
#########################

def _initialise():
    plugins.register_handler(_handle_passcode, type="message")

@asyncio.coroutine
def _handle_passcode(bot, event, command):
    """Handle message forwarding"""
    # Test if message forwarding is enabled
    if not bot.get_config_suboption(event.conv_id, 'passcode_enabled'):
        return
    passcode = event.text
    forwards = bot.get_config_suboption(event.conv_id, 'passcode_to')
    for target in forwards:
        if target:
            print(_("FORWARDING PASSCODE: {}").format(target))
            yield from bot.coro_send_message(target, passcode)
