import hangups
from hangups.ui.utils import get_conv_name
import asyncio
import plugins
from pytz import timezone
import pytz
import datetime

def _initialise(Handlers, bot=None):
    """
    first, you can setup stuff, initialise variables and whatever else!
    """
    plugins.register_user_command(["ping2"]) 
    
    # above command is available to all users
    # Handlers.register_admin_command() if command(s) only available to admins
    return [] # always a blank list

@asyncio.coroutine
def ping2(bot, event, *args):
	"""reply to a ping + responsetime in ms"""
	event_timestamp = event.timestamp
	delta = datetime.datetime.now(pytz.utc) - event_timestamp
	yield from bot.coro_send_message(event.conv, 'pong (' + str(format((delta.total_seconds() * 1000), '.2f')) +'ms)')
	return { "api.response": "pong" }
