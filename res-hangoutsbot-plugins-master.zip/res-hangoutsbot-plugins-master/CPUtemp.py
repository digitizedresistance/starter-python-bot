import os
import plugins

# Gets cpu info.
# writen for a raspberry Pi
# Uses https://github.com/nicmcd/vcgencmd
# Commands: "/bot cput" "/bot cpu" "/bot gpu" "/bot cgpu"

def _initialise(bot):
    plugins.register_admin_command(["cput","cpu","gpu","cgpu"])

def cput(bot, event, *args):
   yield from bot.coro_send_message(event.conv, _("<i><b>{}</b></i>").format(os.popen('vcgencmd measure_temp').readline()))

def cpu(bot, event, *args):
   yield from bot.coro_send_message(event.conv, _("<i><b>{}</b></i>").format(os.popen('vcgencmd get_mem arm').readline()))

def gpu(bot, event, *args):
   yield from bot.coro_send_message(event.conv, _("<i><b>{}</b></i>").format(os.popen('vcgencmd get_mem gpu').readline()))

def cgpu(bot, event, *args):
   yield from bot.coro_send_message(event.conv, _("<i><b>{}</b></i>").format(os.popen('vcgencmd get_mem arm').readline()))
   yield from bot.coro_send_message(event.conv, _("<i><b>{}</b></i>").format(os.popen('vcgencmd get_mem gpu').readline()))
