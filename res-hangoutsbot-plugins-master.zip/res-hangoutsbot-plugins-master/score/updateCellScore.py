#!/usr/bin/python
import json
import requests

# Make request
payload = {'updated': 'Tue Feb 01 12:27:32 ', 'RES': 500000, 'ENL': 400000, 'CP': 5  }
headers = {'content-type': 'application/json'}
url = 'https://127.0.0.1:8004/'
r = requests.post(url, data = json.dumps(payload), headers = headers, verify=False)

