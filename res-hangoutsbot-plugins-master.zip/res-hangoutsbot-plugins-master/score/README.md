Ingress Cell Score Plugin
================
*Author: Karl Franke @Riptides*  
This plugin responds to users' queries with the current region score and allows the admin to configure certain hangouts to recieve alerts when there is less than an hour before the next checkpoint.  
**Full Disclosure: This plugin scrapes the cell score and requires account credentials from a gmail account that is associated with an ingress account to do so.**
# Install  
Copy or symlink the score folder into your plugins directory.  
Install dependencies.  
```bash
pip3 install -r requirements.txt
```  

# Configuration
```json
  "region_score": [
    {
      "certfile": "/path/to/server.pem",
      "name": "127.0.0.1",
      "port": 8004,
      "username": "USERNAME",
      "password": "PASSWORD",
      "limited": 100000,
      "field":
        {
          "minLngE6":-75707859,
          "minLatE6":39662006,
          "maxLngE6":-75746698,
          "maxLatE6":39681297
        }
    }
  ],
```
A custom sink is used to trigger checkpoint alerts, as well as optionally updating the stored region score from an outside source. Set values for `certfile`, `name`, and `port` as you would any other sink. The values for `username` and `password` are the username and password the plugin will use to login to intel and fetch the score. The value for `limited` sets the threshold for hangouts that have subscribed to limited checkpoint alerts. In these hangouts alerts are only sent if `res_score <= (enl_score + limited)`. The values for `field` define which cell to get the score from; the resulting poly does not need to encompass the entire cell, just be contained within the cell. 
# Getting the cell score  
Use the `score command`.
```
/bot score
..
RES: 798766 
ENL: 738615 
Last Updated: Tue Feb 01 12:27:32 
4 checkpoints remaining this cycle.
```
## To force a score update
The plugin automatically updates the score if the stored values are more than an hour old; however, an manual update can also be done.  
`/bot score update`
## Updating the score externally
The plugin can also recieve score updates from an external source. See `updateCellScore.py` for an example http request.

# Checkpoint Alerts
## Triggering alerts
Alerts must be triggered via an http request send to the plugin's sink. See `sendCPalert.py` for an example. You should schedule this request to be made less than 60 minutes before each checkpoint. This could be one with a utility such as `at`.

## Subscribing to alerts
To subscribe a hangout to recieve alerts use the `checkpointalerts` command
```
checkpointalerts: 
   turn checkpoint alerts on or off for a hangouts
   /bot checkpointalerts all - turns on all alerts
   /bot checkpointalerts limited - receive alerts only when the scores are close or RES is losing
   /bot checkpointalerts off - turns them off
```
# Troubleshooting
The most common problem you are likely to encounter is when the score cannot be updated because Google does not recognize the server's IP address during login and presents a security question. To fix this, login to ingress.com/intel manually from the command line using a browser such as lynx. 
