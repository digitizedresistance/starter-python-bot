from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
from threading import Thread
from hangups.ui.utils import get_conv_name
from datetime import datetime

import ssl
import asyncio
import logging
import hangups
import plugins
import json

import time
import bs4
import requests
import re

""" Region score plugin for receiving a region score to store in memory, relaying that score information to hangouts when asked, and for sending alerts to specific hangouts before checkpoint.
config.json will have to be configured as follows:
  "region_score": [
    {
      "certfile": "/path/to/server.pem",
      "name": "127.0.0.1",
      "port": 8004,
      "username": "USERNAME",
      "password": "PASSWORD",
      "limited": 100000,
      "field":
        {
          "minLngE6":-75707859,
          "minLatE6":39662006,
          "maxLngE6":-75746698,
          "maxLatE6":39681297
        }
    }
  ]
  
Author: @Riptides
"""

_externals = {
              "username": "USERNAME",
              "password": "PASSWORD",
              "limited": 100000,
              "field": 
                  {
                    "minLngE6":-75707859,
                    "minLatE6":39662006,
                    "maxLngE6":-75746698,
                    "maxLatE6":39681297,
                  }
             }

def _initialise(Handlers, bot=None):
    if bot:
        score_config = bot.get_config_option('region_score')
        if score_config:
            _externals.update(score_config[0])
        _start_score_sinks(bot)
        plugins.register_admin_command(["checkpointalerts"])
        plugins.register_user_command(["score"])
    else:
        print("Region score plugin could not be initialized.")
    return []

def _start_score_sinks(bot):
    # Start and asyncio event loop
    loop = asyncio.get_event_loop()

    score_sink = bot.get_config_option('region_score')
    itemNo = -1
    threads = []

    if isinstance(score_sink, list):
        for sinkConfig in score_sink:
            itemNo += 1
            try:
                certfile = sinkConfig["certfile"]
                if not certfile:
                    print(_("config.region_score[{}].certfile must be configured").format(itemNo))
                    continue
                name = sinkConfig["name"]
                port = sinkConfig["port"]
            except KeyError as e:
                print(_("config.region_score[{}] missing keyword").format(itemNo), e)
                continue

            # start up score listener in a separate thread
            print("_start_score_sinks()")
            t = Thread(target=start_listening, args=(
              bot,
              loop,
              name,
              port,
              certfile))

            t.daemon = True
            t.start()

            threads.append(t)

    message = _("_start_score_sinks(): {} sink thread(s) started").format(len(threads))
    logging.info(message)

def start_listening(bot=None, loop=None, name="", port=8014, certfile=None):
    webhook = webhookReceiver

    if loop:
        asyncio.set_event_loop(loop)

    if bot:
        webhook._bot = bot

    try:
        httpd = HTTPServer((name, port), webhook)

        httpd.socket = ssl.wrap_socket(
          httpd.socket,
          certfile=certfile,
          server_side=True)

        sa = httpd.socket.getsockname()
        print(_("listener: score sink on {}, port {}...").format(sa[0], sa[1]))

        httpd.serve_forever()
    except IOError:
        # do not run sink without https!
        print(_("listener: region_score : pem file possibly missing or broken (== '{}')").format(certfile))
        httpd.socket.close()
    except OSError as e:
        # Could not connect to HTTPServer!
        print(_("listener: score : requested access could not be assigned. Is something else using that port? (== '{}:{}')").format(name, port))
    except KeyboardInterrupt:
        httpd.socket.close()

class webhookReceiver(BaseHTTPRequestHandler):
    _bot = None

    def _handle_incoming(self, payload):
        if "updated" in payload and "RES" in payload and "ENL" in payload and "CP" in payload:
            self._scripts_push(payload["updated"], payload["RES"], payload["ENL"], payload["CP"])
        elif "alert" in payload:
            sendCpAlerts(webhookReceiver._bot)
        else:
            print(payload)
        print(_("handler finished"))

    def _scripts_push(self, updated, RES, ENL, CP):
        ## Create a place in memory for the score if it doesn't exist
        if not webhookReceiver._bot.memory.exists(["score"]):
            webhookReceiver._bot.memory["score"] = {}
        ## Update saved score
        epoch = int(time.time())
        score = webhookReceiver._bot.memory.get("score")
        score["epoch"] = epoch
        score["updated"] = updated
        score["RES"] = RES
        score["ENL"] = ENL
        score["CP"] = CP
        webhookReceiver._bot.memory["score"] = score
        webhookReceiver._bot.memory.save()
        
        ## **TODO** Trigger Alerts for later **TODO** ##
        # loop = asyncio.get_event_loop()
        # loop.call_later(16200, sendCpAlerts(webhookReceiver._bot))


    def do_POST(self):
        """
           receives post, handles it
       """
        print(_('receiving POST...'))
        data_string = self.rfile.read(int(self.headers['Content-Length'])).decode('UTF-8')
        self.send_response(200)
        message = bytes('OK', 'UTF-8')
        self.send_header("Content-type", "text")
        self.send_header("Content-length", str(len(message)))
        self.end_headers()
        self.wfile.write(message)
        print(_('connection closed'))
        payload = json.loads(data_string)
        print(_("payload {}").format(payload))
        self._handle_incoming(payload)

class Intel(object):
    def __init__(self, email, password, field):
        self.get_cookies(email, password)
        token = re.findall(r'csrftoken=(\w*);', self.cookies)[0]
        self.headers = {
            'accept-encoding' :'gzip, deflate',
            'content-type': 'application/json; charset=UTF-8',
            'cookie': self.cookies,
            'origin': 'https://www.ingress.com',
            'referer': 'https://www.ingress.com/intel',
            'user-agent': 'Mozilla/5.0 (MSIE 9.0; Windows NT 6.1; Trident/5.0)',
            'x-csrftoken': token,
        }
        self.field = {
            'maxLatE6': field['maxLatE6'],
            'minLatE6': field['minLatE6'],
            'maxLngE6': field['maxLngE6'],
            'minLngE6': field['minLngE6'],
        }
        self.point = {
            'latE6': (field['maxLatE6'] + field['minLatE6']) >> 1,
            'lngE6': (field['maxLngE6'] + field['minLngE6']) >> 1,
        }
        
        self.refresh_version()
    def get_cookies(self, email, password):
        email = email + '@gmail.com'
        session = requests.session()
        login_html = session.get('https://www.google.com/accounts/ServiceLogin?service=ah&passive=true&continue=https://appengine.google.com/_ah/conflogin%3Fcontinue%3Dhttps://www.ingress.com/intel&ltmpl=')
        soup_login = bs4.BeautifulSoup(login_html.content, 'html5lib').find('form').find_all('input')
        dico = {}
        for u in soup_login:
            if u.has_attr('value'):
                dico[u['name']] = u['value']

        dico['Email'] = email
        dico['Passwd'] = password
        session.post("https://accounts.google.com/ServiceLoginAuth", data=dico)
        data = {}
        if 'SACSID' in session.cookies and 'csrftoken' in session.cookies:
            data['SACSID'] = session.cookies['SACSID']
            data['csrftoken'] = session.cookies['csrftoken']
        cookiestring = 'SACSID=' + data['SACSID'] + '; csrftoken=' + data['csrftoken'] + ';'
        self.cookies = cookiestring

    def refresh_version(self):
        request = requests.get('https://www.ingress.com/intel', headers=self.headers)
        self.version = re.findall(r'gen_dashboard_(\w*)\.js', request.text)[0]

    def fetch(self, url, payload):
        payload['v'] = self.version
        request = requests.post(url, data=json.dumps(payload), headers=self.headers)
        return request.json()['result']

    def fetch_region(self):
        url = 'https://www.ingress.com/r/getRegionScoreDetails'
        payload = {
            'lngE6': self.point['lngE6'],
            'latE6': self.point['latE6'],
        }
        return self.fetch(url, payload)
        

def checkpointalerts(bot, event, *args):
    """
    turn checkpoint alerts on or off for a hangouts
    /bot checkpointalerts all - turns on all alerts
    /bot checkpointalerts limited - receive alerts only when the scores are close or RES is losing
    /bot checkpointalerts off - turns them off
    """ 
    # Check if memory exists for HOs to alert, and if not start an empty list
    if bot.memory.exists(["checkpointalerts"]):
        alertslist = bot.memory.get("checkpointalerts")
    else:
        alertslist = []
    if bot.memory.exists(["limitedcheckpointalerts"]):
        limitedalertslist = bot.memory.get("limitedcheckpointalerts")
    else:
        limitedalertslist = []
    # Make sure we have arguments
    if args:
        option = args[0]
        # If arg is yes add to memory and send message
        if option == 'all':
            if event.conv_id in alertslist:
                html = "<b>Alerts already enabled for this hangout!</b>"
                bot.send_html_to_conversation(event.conv, html)
            else:
                alertslist.append(event.conv_id)
                bot.memory["checkpointalerts"] = alertslist
                bot.memory.save()
                if event.conv_id in limitedalertslist:
                    limitedalertslist.remove(event.conv_id)
                    bot.memory["limitedcheckpointalerts"] = limitedalertslist
                    bot.memory.save()
                html = "<b>Alerts enabled!</b>"
                bot.send_html_to_conversation(event.conv, html)
        elif option == 'limited':
            if event.conv_id in limitedalertslist:
                html = "<b>Limited alerts already enabled for this hangout!</b>"
                bot.send_html_to_conversation(event.conv, html)
            else:
                limitedalertslist.append(event.conv_id)
                bot.memory["limitedcheckpointalerts"] = limitedalertslist
                bot.memory.save()
                if event.conv_id in alertslist:
                    alertslist.remove(event.conv_id)
                    bot.memory["checkpointalerts"] = alertslist
                    bot.memory.save()
                html = "<b>Limited alerts enabled!</b>"
                bot.send_html_to_conversation(event.conv, html)
        elif option == 'off':
            if event.conv_id in alertslist or event.conv_id in limitedalertslist:
                if event.conv_id in alertslist:
                    alertslist.remove(event.conv_id)
                    bot.memory["checkpointalerts"] = alertslist
                    bot.memory.save()
                if event.conv_id in limitedalertslist:
                    limitedalertslist.remove(event.conv_id)
                    bot.memory["limitedcheckpointalerts"] = limitedalertslist
                    bot.memory.save()
                html = "<b>Alerts disabled!</b>"
                bot.send_html_to_conversation(event.conv, html)
            else:
                html = "<b>Alerts were already disabled for this hangout!</b>"
                bot.send_html_to_conversation(event.conv, html)
        # if arg is unknown send error
        else:
            html = "<b>Unknown argument! Hint: try all, limited, or off</b>"
            bot.send_html_to_conversation(event.conv, html)
    else:
        html = "<b>No argument provided! Hint: try all, limited, or off</b>"
        bot.send_html_to_conversation(event.conv, html)

def sendScore(bot, conv_id, *args):
    print('score')
    updateneeded=0
    cellscores = None
    if args:
        if args[0] == 'update':
            updateneeded = 1
    if bot.memory.exists(["score"]):
        #check epoch and update if necessary
        storedscore = bot.memory.get("score")
        try:
            fmt = '%m-%d-%H'
        
            storedepoch = storedscore['epoch']
            storeddate = datetime.fromtimestamp(storedepoch)
            storedstring = storeddate.strftime(fmt)
            
            now = datetime.now()
            nowstring = now.strftime(fmt)
            
            if not (storedstring == nowstring):
                updateneeded = 1
        except:
            updateneeded = 1
    else:
        updateneeded = 1
        
    if (updateneeded == 1):
        try:
            intel = Intel(_externals['username'], _externals['password'], _externals['field'])
            try:
                scoredic = intel.fetch_region()
                try:
                    RESscore = scoredic["gameScore"][1]
                    ENLscore = scoredic["gameScore"][0]
                    CPnumber = scoredic["scoreHistory"][0][0]
                except Exception as e:
                    RESscore = "0"
                    ENLscore = "0"
                    CPnumber = "0"
                fmt = '%a %b %d %H:%M:%S %Z'
                date = datetime.now()
                date = date.strftime(fmt) + '\n'
                epoch = int(time.time())

                if not bot.memory.exists(["score"]):
                   bot.memory["score"] = {}
                ## Update saved score
                score = bot.memory.get("score")
                score["epoch"] = epoch
                score["updated"] = date
                score["RES"] = RESscore
                score["ENL"] = ENLscore
                score["CP"] = CPnumber
                bot.memory["score"] = score
                bot.memory.save()
            except:
                bot.send_html_to_conversation(conv_id, "error updating score - could not communicate with intel")
        except:
            bot.send_html_to_conversation(conv_id, "error updating score - could not communicate with google")
        
    cellscores = bot.memory.get("score")
    updated = cellscores["updated"]
    RES = cellscores["RES"]
    ENL = cellscores["ENL"]
    CP = cellscores["CP"]
    left = 35 - int(CP)
    bot.send_html_to_conversation(conv_id, _("<b>RES:</b> {} \n <b>ENL:</b> {} \n <b>Last Updated:</b> {}<b>{}</b> checkpoints remaining this cycle.").format(RES, ENL, updated, left))

def sendCpAlerts(bot, *args):

    if bot.memory.exists(["checkpointalerts"]) or bot.memory.exists(["limitedcheckpointalerts"]):
        event = {}
        if bot.memory.exists(["checkpointalerts"]):
            alertslist = bot.memory.get("checkpointalerts")
        else:
            alertslist = []
        if bot.memory.exists(["limitedcheckpointalerts"]):
            limitedalertslist = bot.memory.get("limitedcheckpointalerts")
        else:
            limitedalertslist = []
        for conv_id in alertslist:
            currentMinute = datetime.now().minute
            currentMinute = int(currentMinute)
            minToCP = 59 - currentMinute
            html = str(minToCP) + " minutes to checkpoint!"
            bot.send_html_to_conversation(conv_id, html)
            sendScore(bot, conv_id)
        try:
            ENL = bot.memory.get_by_path(["score", "ENL"])
            ENL = int(ENL)
            RES = bot.memory.get_by_path(["score", "RES"])
            RES = int(RES)
            if RES <= (ENL+_externals["limited"]):
                for conv_id in limitedalertslist:
                    currentMinute = datetime.now().minute
                    currentMinute = int(currentMinute)
                    minToCP = 59 - currentMinute
                    html = str(minToCP) + " minutes to checkpoint!"
                    bot.send_html_to_conversation(conv_id, html)
                    sendScore(bot, conv_id)
        except Exception as e:
            print("score_limited_alerts: {}".format(e))
    else:
        print("No checkpointalerts found in memory")

def score(bot, event, *args):
    """
    show region cell score
    """
    sendScore(bot, event.conv_id, *args)
