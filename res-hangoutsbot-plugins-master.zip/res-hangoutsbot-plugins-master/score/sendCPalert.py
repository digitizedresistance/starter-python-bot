#!/usr/bin/python
import json
import requests

# Make request
payload = {'alert': 'now'}
headers = {'content-type': 'application/json'}
url = 'https://127.0.0.1:8004/'
r = requests.post(url, data = json.dumps(payload), headers = headers, verify=False)

