import hangups
from hangups.ui.utils import get_conv_name
import asyncio
import plugins
from commands import command

def _initialise(Handlers, bot=None):
    """
    first, you can setup stuff, initialise variables and whatever else!
    """
    
    # above command is available to all users
    # Handlers.register_admin_command() if command(s) only available to admins
    return [] # always a blank list

@command.register_unknown
def unknown_command(bot, event, *args):
    """handle unknown commands and do nothing"""


@command.register_blocked
def blocked_command(bot, event, *args):
    """handle blocked commands and do nothing"""

