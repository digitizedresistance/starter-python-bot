import asyncio
import json
import requests
import json
import subprocess
import datetime

from urllib.parse import urlparse, parse_qs
from hangups.ui.utils import get_conv_name

url = "http://localhost:31337/"
headers = {'content-type': 'application/json'}

def _initialise(Handlers, bot=None):
    Handlers.register_user_command(["iitc", "iitcregion", "iitcdraw", "region", "regions", "stats", "score", "usage", "scrape", "index"])
    Handlers.register_admin_command(["reloadcasper"])
    return []

def reloadcasper(bot, event, *args):
    subprocess.call("killall phantomjs", shell=True)
    bot.send_html_to_conversation(event.conv_id, "Done")

def iitc(bot, event, *args):
    """
    Returns an iitc screenshot for the requested region
    """
    loadingText = "Loading"
    iitc_map(bot, event, loadingText, *args)

def scrape(bot, event, *args):
    """
    Humourous alias for iitc
    """
    loadingText = "Scraping"
    iitc_map(bot, event, loadingText, *args)

def index(bot, event, *args):
    """
    Alias for regions
    """
    iitcregion(bot, event)

def iitc_map(bot, event, loadingText, *args):
    usage = bot.get_config_option('iitc_usage') or {'today_date':'', 'allTime':0}
    if (usage['today_date'] != datetime.datetime.today().day):
      usage['today_date'] = datetime.datetime.today().day
      usage['today'] = 1
    else:
      usage['today'] += 1
    usage['allTime'] += 1
    bot.config.set_by_path(['iitc_usage'], usage)
    bot.config.save()

    config = bot.get_config_option('iitcregion') or {}
    for region in args:
        region = region.lower()
        if region == 'region' or region == 'regions':
            iitcregion(bot, event)
        elif region == 'stats' or region == 'statistics' or region == 'count' or region == 'balance':
          payload = {"action":"stats", "callback":"https://localhost:31338/{}".format(event.conv_id)}
          try:
            r = requests.post(url, data = json.dumps(payload), headers = headers, verify=False)
            bot.send_html_to_conversation(event.conv_id, "<i>{} {}, please wait</i>".format(loadingText, region))
          except requests.exceptions.ConnectionError:
            bot.send_html_to_conversation(event.conv_id, "<i>Casper not ready :(</i>")
        elif region == 'score' or region == 'scores':
          payload = {"action":"score", "callback":"https://localhost:31338/{}".format(event.conv_id)}
          try:
            r = requests.post(url, data = json.dumps(payload), headers = headers, verify=False)
            bot.send_html_to_conversation(event.conv_id, "<i>{} {}, please wait</i>".format(loadingText, region))
          except requests.exceptions.ConnectionError:
            bot.send_html_to_conversation(event.conv_id, "<i>Casper not ready :(</i>")
        elif region in config:
            payload = json.loads(json.dumps(config[region]))
            payload["name"] = region
            payload["callback"] = "https://localhost:31338/{}".format(event.conv_id)
            
            try:
              r = requests.post(url, data = json.dumps(payload), headers = headers, verify=False)
              bot.send_html_to_conversation(event.conv_id, "<i>{} {}, please wait</i>".format(loadingText, region))
            except requests.exceptions.ConnectionError:
              bot.send_html_to_conversation(event.conv_id, "<i>Casper not ready :(</i>")
        else:
            r = requests.get("https://maps.googleapis.com/maps/api/geocode/json?address={}&region=NZ".format(region))
            if r.json()['status'] != 'OK':
              bot.send_html_to_conversation(event.conv_id, "<i>Region {} not defined</i>".format(region))
              continue
            latlng = r.json()['results'][0]['geometry']['location']
            region = r.json()['results'][0]['formatted_address']
            payload = {'latlng': [latlng['lat'], latlng['lng']], 'zoom': 14}
            payload["name"] = region
            payload["callback"] = "https://localhost:31338/{}".format(event.conv_id)

            try:
              r = requests.post(url, data = json.dumps(payload), headers = headers, verify=False)
              bot.send_html_to_conversation(event.conv_id, "<i>{} {}, please wait</i>".format(loadingText, region))
            except requests.exceptions.ConnectionError:
              bot.send_html_to_conversation(event.conv_id, "<i>Casper not ready :(</i>")

def iitcregion(bot, event, name=None, url=None):
  """
  Adds a region to the bot's memory.
  Usage: /bot iitcregion name iitc_url
  """
  config = bot.get_config_option('iitcregion') or {}
  if not name:
    config = list(config.keys())
    config.sort()
    regions = ", ".join(config)
    bot.send_html_to_conversation(event.conv_id, "<i>{}: Configured regions: {}</i>".format(event.user.full_name, regions))
    return
  if not url:
    data = json.dumps(config[name])
    bot.send_html_to_conversation(event.conv_id, data)
    return
  parsed = urlparse(url)
  query = parse_qs(parsed.query)
  latlng = list(map(float, query['ll'][0].split(',')))
  zoom = int(query['z'][0])
  obj = {"latlng":latlng, "zoom":zoom}
  name = name.lower()
  config[name] = obj
  bot.config.set_by_path(["iitcregion"], config)
  bot.config.save()
  bot.send_html_to_conversation(event.conv_id, "<i>{}: {} saved</i>".format(event.user.full_name, name))

def region(bot, event, name=None, url=None):
  """
  Adds a region to the bot's memory.
  Usage: /bot iitcregion name iitc_url
  """
  iitcregion(bot, event, name, url)

def regions(bot, event, name=None, url=None):
  """
  Adds a region to the bot's memory.
  Usage: /bot iitcregion name iitc_url
  """
  iitcregion(bot, event, name, url)

def stats(bot, event):
  """
  Prints the stats for the current region
  """
  iitc(bot, event, "stats")

def score(bot, event):
  """
  Prints the score for the current region
  """
  iitc(bot, event, "score")

def usage(bot, event, *args):
  usage = bot.get_config_option('iitc_usage')
  bot.send_html_to_conversation(event.conv_id, "I have handled {} screenshot requests today, and {} all time".format(usage['today'], usage['allTime']))

def iitcdraw(bot, event, action=None, name=None, plan=None):
  """
  Stores json for field plans, and adds or removes them from the intel map. Use the command "/bot iitcdraw store plan_name json" to store some json, then call "/bot iitcdraw plan_name" to draw it. Then take screenshots as per normal. Use "/bot iitcdraw clear to clear all drawn items"
  """
  if not action:
    config = bot.get_config_option('iitcdraw')
    plans = ', '.join(config)
    bot.send_html_to_conversation(event.conv_id, "<i>{}: Configured plans: {}</i>".format(event.user.full_name, plans))
    return
  elif action == 'store' and name and plan:
    name = name.lower()
    try:
      plan = json.loads(plan)
    except ValueError:
      pass
    bot.config.set_by_path(["iitcdraw", name], plan)
    bot.config.save()
    bot.send_html_to_conversation(event.conv_id, "<i>{}: {} saved</i>".format(event.user.full_name, name))
  elif action == 'clear':
    try:
      r = requests.post(url, data = json.dumps({"action":"clear"}), headers = headers, verify=False)
      bot.send_html_to_conversation(event.conv_id, "<i>Clear sent to Casper</i>")
    except requests.exceptions.ConnectionError:
      bot.send_html_to_conversation(event.conv_id, "<i>Casper not ready :(</i>")
  else:
    action = action.lower()
    try:    
      plan = bot.config.get_by_path(["iitcdraw", action])
    except KeyError:
      bot.send_html_to_conversation(event.conv_id, "<i>No such plan: {}</i>".format(action))
      return
    if type(plan) is list:
      plan = json.dumps(plan)
    payload = {"action": "load", "json": plan}
    try:
      r = requests.post(url, data = json.dumps(payload), headers = headers, verify=False)
      bot.send_html_to_conversation(event.conv_id, "<i>{} sent to Casper</i>".format(action))
    except requests.exceptions.ConnectionError:
      bot.send_html_to_conversation(event.conv_id, "<i>Casper not ready :(</i>")

