// casperjs --web-security=false --ignore-ssl-errors=true --verbose --cookies-file=casperjs.cookie iitc.js

var casper = require('casper').create({
    //verbose: true,
    //logLevel: 'debug',
});

casper.start();
casper.userAgent('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36');
casper.page.settings.resourceTimeout = 62 * 1000;
casper.options.retryTimeout = 2000;
casper.options.waitTimeout = 2 * 60 * 1000;
casper.viewport(1920, 1080);

var l = '__USERNAME__';
var p = '__PASSWORD__';

casper.on('remote.message', function (message) {
    this.echo(new Date() + " " + message);
});
casper.on('page.error', function (msg, trace) {
  if (typeof msg == 'object') {
    try {
      var utils = require('utils');
      msg = utils.dump(msg);
    } catch (err) {this.echo("Unable to stringify")}
  }
  this.echo(new Date() + "Error: " + msg, 'ERROR')
});


casper.thenOpen('https://www.ingress.com/intel');
casper.log(new Date() + " loading");
casper.then(function() {
    var signInButton = '.button_link';
    if (this.exists(signInButton)) {
        console.log(new Date() + " following Sign In button..");
        casper.click(signInButton);
    }
});
casper.then(function() {
    if (casper.getCurrentUrl().indexOf('ServiceLogin') > 0) {
        this.sendKeys("#Email", l);
        this.click("#next");
    }
});
casper.then(function() {
  if (casper.getCurrentUrl().indexOf('ServiceLogin') > 0) {
    this.sendKeys("#Passwd", p);
    console.log(new Date() + " entered login and password");
    this.click("#signIn");
  }
});
casper.then(function() {
    if (casper.getCurrentUrl().indexOf('https://appengine.google.com/_ah/loginfo') === 0) {
        casper.evaluate(function() {
            document.getElementById('persist_checkbox').checked = true;
            document.getElementsByTagName('form').submit();
        });
        console.log(new Date() + " accepted app engine request");
    }
    if (this.exists('.error-msg')) {
        this.echo(new Date() + " login failed! Check login details", 'ERROR');
        casper.exit();
    }
});
casper.waitForUrl(/https:\/\/www\.ingress\.com\/intel/);

// Inject IITC
casper.then(function _injectIITC() {
    casper.echo("inject to:" + casper.getCurrentUrl());
    casper.evaluate(function () {
        var head = document.getElementsByTagName('head')[0];
        
        var scripts = [
            "https://secure.jonatkins.com/iitc/test/total-conversion-build.user.js",
            "https://secure.jonatkins.com/iitc/test/plugins/privacy-view.user.js",
            "https://secure.jonatkins.com/iitc/test/plugins/portal-highlighter-high-level.user.js",
            "https://secure.jonatkins.com/iitc/test/plugins/portal-level-numbers.user.js",
            "https://secure.jonatkins.com/iitc/test/plugins/draw-tools.user.js",
            "https://secure.jonatkins.com/iitc/test/plugins/portal-counts.user.js",
            "https://secure.jonatkins.com/iitc/test/plugins/player-tracker.user.js",
        ];
 
        for (i in scripts) {
          var script = document.createElement('script');
          script.type = 'text/javascript';
          script.src = scripts[i];
          head.appendChild(script);
        }
        
    });
});

casper.waitFor(function checkLoaded() {
  return this.evaluate(function() { return window.iitcLoaded } );
});

casper.then(function _injectCustomIITC () {
  casper.evaluate(function() {
      window.isTouchDevice = function() { return false; };
      window.plugin.playerTracker.closeIconTooltips = function() {};
      var head = document.getElementsByTagName('head')[0];

      var scripts = [
          "https://leaflet.github.io/Leaflet.label/leaflet.label.js",
          "https://secure.jonatkins.com/iitc/test/plugins/cross_link.user.js",
          "https://secure.jonatkins.com/iitc/test/plugins/done-links.user.js",
          "https://6fd22b7b61df8f5179ca5bd1548cce4dd8874e1d-www.googledrive.com/host/0B91GPRw_uBY1LUVNNWZOdHUxSFE/iitc-custom-player-icons.user.js",
          "https://6fd22b7b61df8f5179ca5bd1548cce4dd8874e1d-www.googledrive.com/host/0B91GPRw_uBY1LUVNNWZOdHUxSFE/iitc-field-opacity.user.js",
          "https://6fd22b7b61df8f5179ca5bd1548cce4dd8874e1d-www.googledrive.com/host/0B91GPRw_uBY1LUVNNWZOdHUxSFE/iitc-show-more.user.js",
          "https://6fd22b7b61df8f5179ca5bd1548cce4dd8874e1d-www.googledrive.com/host/0B91GPRw_uBY1LUVNNWZOdHUxSFE/iitc-player-tracker-names-alt.user.js",
          "https://6fd22b7b61df8f5179ca5bd1548cce4dd8874e1d-www.googledrive.com/host/0B91GPRw_uBY1LUVNNWZOdHUxSFE/iitc-hide-ui.user.js",
          "https://6fd22b7b61df8f5179ca5bd1548cce4dd8874e1d-www.googledrive.com/host/0B91GPRw_uBY1LUVNNWZOdHUxSFE/iitc-multiple-details.user.js",
      ];
      for (i in scripts) {
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = scripts[i];
        head.appendChild(script);
      }
    });
  casper.echo(new Date() + " injected");
});


// Google Road Layer, Portal Levels, Hide sidebar
casper.then(function setIITCOption() {
    this.evaluate(function () {
      console.log('isTouchDevice:' + window.isTouchDevice());
      window.alert = function(msg) {console.log("ALERT:"+msg)}
      
        var baseLayers = window.layerChooser.getLayers().baseLayers;
        for (var l in baseLayers) {
            if (baseLayers[l].name == 'Google Default Ingress Map') {
                window.layerChooser.showLayer(baseLayers[l].layerId);
                console.log(baseLayers[1].name + " enabled");
                break;
            }
        }

        var overlayLayers = window.layerChooser.getLayers().overlayLayers;
        for (var l in overlayLayers) {
            var name = overlayLayers[l].name;
            if (name == 'Portal Levels' || // name == 'DEBUG Data Tiles' ||
                name == 'Drawn Items' || name == 'Cross Links' || name == 'Done Links' ||
                name.indexOf('Player Tracker')>=0) {
                window.layerChooser.showLayer(overlayLayers[l].layerId);
                console.log(name + " enabled");
            } else if (name == 'DEBUG Data Tiles') {
                window.layerChooser.showLayer(overlayLayers[l].layerId, false);
                console.log(name + " disabled");
            }
        }

        var sidebar = $('#scrollwrapper');
        if (sidebar.is(':visible')) {
            $('#sidebartoggle').click();
        }
    });
});

function checkStatus() {
    var mapLoaded = casper.page.evaluate(function () {
        var status = window.mapDataRequest.getStatus();
        console.log(status.long + " / " + status.short + " / " + Math.floor(status.progress * 100) + '%');
        return status.short == 'done' || status.short == 'errors' || status.short == 'idle';
    });
    return mapLoaded;
}

var queue = [];
var loading = false;
var lastArea = "";

function capture(options) {
    queue.push(options);

    if (loading) return;
    loading = true;

    setTimeout(processQueue, 100);
}

function sendPNG(cur) {
  var png = casper.captureBase64('png');
  casper.page.evaluate(function (cur, png) {
    var res = __utils__.sendAJAX(cur.callback, 'POST',
        JSON.stringify({
            image: {base64encoded:png, filename: cur.name + " at " + new Date() + ".png"},
            echo: cur.name
        }), false, {
            contentType: 'application/json'
        });
    console.log(JSON.stringify(res));
  }, cur, png);
}

function processQueue() {
    var cur = queue.shift();
    if (!cur) {
        loading = false;
        return;
    }
    
    if (cur.action == 'stats') {
      cur.name = lastArea + " stats";
      casper.page.evaluate(function() { window.plugin.portalcounts.getPortals(); });
      sendPNG(cur);
      casper.page.evaluate(function() { for (var d in window.DIALOGS) { $(window.DIALOGS[d]).dialog('close') }; });
      processQueue();
      return;
    }

    if (cur.action == 'score') {
      cur.name = lastArea + " score";
      casper.page.evaluate(function() {
        window.regionScoreboard();
	setTimeout(function() {$('.ui-accordion').accordion('destroy')}, 4000)
      });
      setTimeout(function(cur) {
        sendPNG(cur);
        casper.page.evaluate(function() { for (var d in window.DIALOGS) { $(window.DIALOGS[d]).dialog('close') }; });
        processQueue();
      }, 5000, cur);
      return;
    }
    
    if (cur.portals) {
      casper.page.evaluate(function(portals) {
        var timeout = 10000;
        for (var i in portals) {
          setTimeout(function(guid) {
            window.portalDetail.request(guid);
            console.log('click '+guid);
          }, timeout, portals[i]);
          timeout += 500;
        }
      }, cur.portals);
    }

    lastArea = cur.name;

    casper.page.evaluate(function (cur) {
        console.log(JSON.stringify(cur));
        window.idleReset();
        window.map.setView(cur.latlng, cur.zoom);
        //window.mapDataRequest.mapMoveEnd();
        //window.mapDataRequest.setStatus('refreshing');
        window.mapDataRequest.refresh();
    }, cur);

    var step = 0;
    var interval = setInterval(function _check(self) {
        if (cur.portals && step > 10 && checkStatus() || !cur.portals && checkStatus() || ++step > 30) {
            clearInterval(interval);

            casper.echo(JSON.stringify(cur));
            sendPNG(cur);
            casper.page.evaluate(function() { for (var d in window.DIALOGS) { $(window.DIALOGS[d]).dialog('close') }; });

            processQueue();
        } else {
            casper.echo("wait " + step);
        }
    }, 2000);
}

function draw_action(data) {
  casper.page.evaluate(function (data) {
    if (data['action'] == 'load') {
      window.prompt = function() { return data['json'] };
      window.plugin.drawTools.optPaste();
    } else if (data['action'] == 'clear') {
      window.confirm = function() { return true };
      window.plugin.drawTools.optReset()
    }
  }, data);
}

casper.run(function () {
    var server = require('webserver').create();

    service = server.listen(31337, function (request, response) {
        try {
            console.log('Request at ' + new Date());
            console.log(JSON.stringify(request, null, 4));

            var postRaw = (request.postRaw || request.post) + "";
            var data = JSON.parse(postRaw);

            if (data['action'] && data['action'] != 'stats' && data['action'] != 'score') {
              draw_action(data);
            } else {
              capture(data);
            }

            response.statusCode = 200;
            response.headers = {
                'Cache': 'no-cache',
                'Content-Type': 'text/plain'
            };
            response.write(queue.length);
            response.close();
        } catch (e) {
            casper.echo(""+e);
            response.statusCode = 500;
            response.write(""+e);
            response.close();
        }
    });
});
