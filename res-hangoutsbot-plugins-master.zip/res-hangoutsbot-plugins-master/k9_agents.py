# Written by agent KillNine
# Dependency: none
# Config: none
# Description: 'agents' will list nicknames in a room next to Real Names.  If agents use setnickname to set their IGN it will be listed.
# 'agents whois nickname' will tell you the Real Name of agent nickname.

import hangups
import plugins

def _initialise(bot):
    plugins.register_user_command(["agents"])
    
def agents(bot, event,*args):
    print(len(args))
    
    segments = []
    
    if len(args) == 0:
        segments = list_all(bot, event,args)
    
    elif str(args[0]).lower()=='whois':
        print('Looking up agent by nickname.')
        segments = whois(bot, event,args)
        
    yield from bot.coro_send_message(event.conv, segments)

def whois(bot, event,args):
    segments = []
    
    #not enough parameters
    if len(args)<2:
        segments.append(hangups.ChatMessageSegment('Mind telling me whom it is you seek? I need an IGN. I''m not a mind reader!', is_bold=True))
    else:
        segments =  find_by_nickname(bot, event,args)  
    return segments
    

def find_by_nickname(bot, event,args):
    segments = []
    target_nick = args[1]
    result = 'Not found'

    for user in bot._user_list._user_dict:
        curr_nick = bot.user_memory_get(user.chat_id, 'nickname')
        if None != curr_nick and curr_nick.lower() ==  target_nick.lower():
            if event.user_id.chat_id == user.chat_id:
                result = "It is important for one to find oneself.  Well done!"
            else:
                result = bot.user_memory_get(user.chat_id, '_hangups')['full_name']
            break
    segments.append(hangups.ChatMessageSegment(str(target_nick) + ' is: ' + str(result)))
    return segments

# This is called if no additional parameters are specified.    
def list_all(bot, event,args):
    bot_id = bot._user_list._self_user.id_[0]

    segments = []
    for participant in event.conv._conversation.participant_data:
        curr_chat_id = participant.id_.chat_id
        
        try:
            if bot_id == curr_chat_id:
                continue
            
            full_name = bot.user_memory_get(curr_chat_id, '_hangups')['full_name']
            nickname = bot.user_memory_get(curr_chat_id, 'nickname')
            
            if full_name is None:
                print (' Does not have a full name ' + str(curr_chat_id))
                continue

            if nickname is not None:
                segments.append(hangups.ChatMessageSegment('['+ nickname +']', is_bold=True))
                segments.append(hangups.ChatMessageSegment(' - ' + full_name))
            else:
                segments.append(hangups.ChatMessageSegment('[ UNKNOWN ]', is_bold=True))
                segments.append(hangups.ChatMessageSegment(' - ' + full_name ))
                
            segments.append(hangups.ChatMessageSegment('\n', hangups.SegmentType.LINE_BREAK))     
        except:
            print('Something went wrong with participant: ' + str(full_name) + " id: " + str(curr_chat_id))
    return segments
