# res-hangoutsbot-plugins
Private repository curating plugins available for resistance only. **Warning:** Don't forget to add your newly added plugin to the list below.


### Plugins
- [**Agents**](k9_agents.py): Plugin the will list nicknames next to hangout names of anyone in the current hangout if the IGN was set using the bot's setnickname function. Use the command "agents" to get a list.
    - **dependencies** - none
    - **config.json** - none
    - **usage**
        - "! agents" - lists IGN next to name of everyone in hangout
        - "! agents whois <IGN>" - return hangout name of agent if the bot knows them and they have set their nickname.
-  [**Botdoc**](botdoc.py) : You can add a general bot documentation. _e.g: ! botdoc | ! setbotdoc | ! setbotdoc clear_
- [**Cell Score**](score/) : Plugin to fetch cell score and for sending alerts to specific hangouts before checkpoint.
-  [**Checkpoints**](checkpoints.py) : This plugin will display ingress checkpoints for the day in question. _e.g. ! cp today | !cp monday_
-  [**Checkpoint**](checkpoint.py) : Alternative checkpoint plugin, also shows checkpoint numbers. _e.g. ! cp | ! cycle | ! cps [\<date\> [\<time\>]]_
    - Requirements: python pytz & python-dateutil modules
- [**Connect**](connect.py) : Easily link hangouts together and let people join via keyword 
- [**Cput**](CPUtemp.py) : Gives cpu data in hangouts. (For pi bots). 
- [**Directions**](directions.py) : Gives an ETA in response to natural language questions, triggered by certain words. Requires `googlemaps`, and a [`maps_api_key`](https://developers.google.com/maps/documentation/directions/get-api-key) parameter. Takes an optional [`directions_geobias`](https://en.wikipedia.org/wiki/Country_code_top-level_domain) config parameter. _e.g. How long does it take to get from Sydney to Parramatta by bus/train/foot/bicycle?_
- [**Distances**](distances.py) : Calculates distances between portals from portal links or geocoordinates and gives some mod considerations. 
-  [**Events**](https://github.com/DanielMartinus/Event-plugin-hangoutsbot) : Easily create and join events in your hangout. Support for more than one event per hangout included.
- [**Farm status**](farmstatus.py) : Cross-conversational tldr for farms/portal clusters _e.g. ! status farmname | ! status set farmname my update_
-  [**gtldr**](gtldr.py) : Global tldr; Same tldr globally, use tags or tools from Kil's plugin pack to restrict command.  _e.g: ! gtldr_
-  [**Lmgtfy**](lmgtfy.py) : This is a simple url parser plugin for lmgtfy.com. _e.g: ! lmgtfy how do I walk in Ingress?_
- [**Os_uptime**](os_uptime.py) : Get the os uptime.. _e.g: ! os_uptime_
- [**Passcodes**](passcodes.py) : Used for forwarding passcodes from one room to another (recommended to use in conjunction with ResEx)
-  [**Ping2**](ping2.py) : This is an extension to the ping command and gives the response time of your bot in miliseconds. _e.g: ! ping2_
    - Requirements: python pytz module
- [**Range**](range.py) : Allows you to request the range of a portal supplying its resonators and its mods. _e.g. ! range resonators mods_
- [**Silentmode**](silentmode.py) : This plugin makes the bot not respond to wrong commands or commands the user has no access to. Especially useful for annoying users or admins who have set a illogical botalias. 
- [**Smurfling Lessons**](smurfling.py) : This plugin pulls up screenshots of the smurfling lessons or provides the link to all. _e.g: ! sl <#>, ! sl 
random, ! sl list, and ! < keyword >_
- [**Sun**](k9_sun.py) : This plugin will provide solar information for today for a given location, including 'Dawn', 'Sunrise', 'Noon', 'Dusk', 'Sunset' with a configurable depression of 'civil', 'nautical', 'astronomical'
    - **dependencies** - Astral, pytz, geopy
    - **usage** sun <location (accepts textual address or postal code)> <solar depression (optional, defaults to civil)>
- [**Welcome**](welcome.py) : This plugin sends a message privately to people who are added to a Hangout. Useful for giving a quick intro to the Hangout, and sends a message in the Hangout saying that they've been sent a message (in case message requires invitation acceptance).
 
### Reswue plugins
All plugins related to reswue such as **reswar scoreboard** and **reswue to hangouts** are [here](reswue)



### Scripts
-  [**Pushbullet Bot Restart**](Botrestart.py) : Run this instead of normal startup command.  Be sure to add to the hangoutsbot folder, and tweak the startup command as required.  You also must register your Pushbullet API with the bot for this to work.

## Contributors
- [@frd , Tero] (https://plus.google.com/u/0/110269266540992054248) [[score](score.py|reswue_scoreboard_backend.pl)]
- [@tgxn, Domenic](https://plus.google.com/+DomenicHorner/posts) [[checkpoints](checkpoints.py)]
- [Matthew](https://plus.google.com/u/0/+MatthewSmissaert/about) [[lmgtfy](lmgtfy.py)] [[ping2](ping2.py)] [[os_uptime](os_uptime.py)] [[Silentmode](silentmode.py)] 
- [@TNGHT, Dion](https://plus.google.com/u/0/+DionSegijn/about) [[events](https://github.com/DanielMartinus/Event-plugin-hangoutsbot)] [[connect](connect.py)]
- [@keo321, Keo](https://plus.google.com/u/0/112913949320114684553/about) [[distances](distances.py)][[farmstatus](farmstatus.py)][[smurfling](smurfling.py)]
- [@mrDries, Dries](https://plus.google.com/u/0/114977301584242055937) [[cput](CPUtemp.py)]
- [@jkr, Jörn](https://plus.google.com/+JörnWhite/about) enhancements to [[checkpoint](checkpoint.py)], orignally by [@redleader36, Matt](https://plus.google.com/u/0/+MattUrich/about)
- [@neonninja, Nick](https://plus.google.com/u/0/+NickYoungAndHisWaifu) [[reswar](reswar.py)]
- [@nylonee, Nihal](https://plus.google.com/+NihalMirpuri/posts) [[passcodes](passcodes.py)]
- [@Riptides, Karl](https://plus.google.com/+KarlFranke/posts) [[Cell Score](score/__init__.py)]
- @KillNine, Gene [[sun](k9_sun.py)]
- [@cd334, Dani](https://www.google.com/+D%C3%A1nielCzig%C3%A1ny) [[botdoc](botdoc.py)]

_People having their plugins in this repository will/can be mentioned here_
