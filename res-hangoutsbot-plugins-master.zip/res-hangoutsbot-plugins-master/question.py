import logging
import plugins
logger = logging.getLogger(__name__)

def _initialise(bot):
    plugins.register_user_command(["que"])
    
def que(bot, event, *args):
    parameters = list(args)
    if parameters:
        command = parameters[0]
    else:
        command = None
        
    que_data = read_memory(bot,event.conv_id)
    statuses = que_data.get('statuses') or {}

    if command in ['yes', 'maybe', 'no']:
        statuses[event.user.full_name] = {'yes': 'yes', 'maybe': 'maybe', 'no': 'no'}[command]
        yield from bot.coro_send_message(event.conv, _("{} que <b>{}</b>").format(event.user.full_name, command))
    elif command == 'create':
        if len(parameters) > 2:
            question = " ".join(parameters[1:])
            que_data['question'] = question
            yield from bot.coro_send_message(event.conv, _("{} que <b>Question added</b>").format(event.user.full_name))

    elif command is None:
        status_yes   = users_by_status(statuses, 'yes')
        status_maybe = users_by_status(statuses, 'maybe')
        status_no    = users_by_status(statuses, 'no')
        question     = que_data.get('question') or 'Question not set' 
        yield from bot.coro_send_message(event.conv,
            _("<b>QUE</b> {}<br><b>Yes ({}):</b> {}<br><b>Maybe ({}):</b> {}<br><b>No ({}):</b> {}").format(
                question,
                len(status_yes),
                ", ".join(status_yes),
                len(status_maybe),
                ", ".join(status_maybe),
                len(status_no),
                ", ".join(status_no)))
    elif command == 'clear':
        que_data = {}
        statuses = {}
        yield from bot.coro_send_message(event.conv, _("QUE: data cleared!"))
    elif command == 'help':
        help_message = """Que-commands:
            que - show questions
            que   <yes|maybe|no> - answer to question
            que clear - removes all data of question"""
        yield from bot.coro_send_message(event.conv, _(help_message))
    else:
        yield from bot.coro_send_message(event.conv, _("Answer Yes/Maybe/No"))

    que_data['statuses'] = statuses
    bot.memory.set_by_path(["que",event.conv_id], que_data)
    bot.memory.save()
    
def users_by_status(statuses, status):
    result = []
    for user, user_status in statuses.items():
        if user_status == status:
            result.append(user)
    return result

def read_memory(bot,conv_id):
    que_data = {}
    if bot.memory.exists(["que",conv_id]):
        que_data = bot.memory.get_by_path(["que",conv_id])
    return que_data
